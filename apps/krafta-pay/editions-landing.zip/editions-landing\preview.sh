#!/bin/bash
# Rebuild, restart the production server, and capture the hero timeline.
#
#   bash scripts/preview.sh            # build + serve + shoot
#   bash scripts/preview.sh --probe    # also print the framing measurements
#   bash scripts/preview.sh --serve    # build + serve only
#
# The restart is not optional politeness: `next start` keeps serving the .next it
# booted with, so a rebuild alone leaves the old chunks live and the page 500s on
# a chunk hash that no longer exists. That failure is silent in the browser — the
# hero just falls back to its static backdrop — so it is worth doing properly.
#
# Port comes from the environment so this works in any host app:
#   PORT=4000 bash scripts/preview.sh
#
# pkill does not reach the Windows process, hence the netstat/taskkill path.
set -e
PORT=${PORT:-3000}
cd "$(dirname "$0")/.."

npm run build 2>&1 | grep -E "✓ Compiled|Failed|error|Error" || true

PID=$(netstat -ano -p tcp 2>/dev/null | grep "LISTENING" | grep ":$PORT " | awk '{print $NF}' | head -1)
if [ -n "$PID" ]; then
  echo "stopping old server (pid $PID)"
  taskkill //PID "$PID" //F >/dev/null 2>&1 || true
  sleep 2
fi

nohup npx next start -p $PORT > /tmp/next$PORT.log 2>&1 &
for i in $(seq 1 20); do
  sleep 1
  code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT" || true)
  [ "$code" = "200" ] && break
done
echo "server: ${code:-down} on :$PORT"
[ "$code" = "200" ] || { echo "--- server log ---"; tail -20 /tmp/next$PORT.log; exit 1; }

[ "$1" = "--serve" ] && exit 0

node scripts/shoot.mjs "${@}"
[ "$1" = "--probe" ] && node scripts/frame-probe.mjs
exit 0
