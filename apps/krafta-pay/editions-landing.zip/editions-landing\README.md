# Editions landing page — image-based hero

A scroll-scrubbed WebGL hero built from **cut-out images**, not 3D models. The
camera, beat timing and contact spark are real three.js; the figures are textured
planes, so the whole thing needs three image files and no mesh pipeline.

```bash
npm install
npm run preview        # build, serve on :3200, capture the hero timeline
```

Captures land in `captures/`.

---

## Copying it into another app

```bash
node scripts/install-into.mjs ../my-app --dry-run   # see what it would do
node scripts/install-into.mjs ../my-app
```

It copies the components, `lib/editions.ts`, the images and the capture harness,
refuses to overwrite files that already exist (pass `--force` to override), then
prints the handful of steps it cannot do for you. Those are:

1. `npm i three` — the only runtime dependency the page adds.
2. **One line** in the stylesheet that imports Tailwind:

   ```css
   @import "tailwindcss";
   @import "../components/landing.css";   /* <- add this */
   ```

   Tailwind 4 resolves `@theme` at build time, so a JS import will not work.
   Without this line the page renders unstyled.
3. Two font variables — `--font-grotesk` and `--font-serif`'s `--font-garamond` —
   set in the host's `layout.tsx`. Any grotesk + serif pair works; only the
   variable names matter.
4. Render it:

   ```tsx
   import { LandingPage } from "@/components/LandingPage";
   export default function Page() { return <LandingPage />; }
   ```

`LandingPage` is self-contained: it wraps itself in `.editions-landing`, which
sets its own background, text colour and font rather than inheriting from the
host's `body`. That matters — several headings carry no colour class, and in an
app with default body styles the display headline rendered black on black until
the wrapper was added.

Requires the `@/*` path alias. If the host uses a different one, adjust the
imports at the top of `LandingPage.tsx`.

Verified end to end: installed into a bare Next 16 app with nothing but
`@import "tailwindcss"`, built, and captured — hero renders, spark fires, no
console errors across the full page.

> **Attribution.** The layout, palette and typographic scale were measured off
> [shopify.com/editions/winter2026](https://www.shopify.com/editions/winter2026),
> and `lib/editions.ts` still carries Shopify's marketing copy. Shopify's name,
> product names and content belong to Shopify Inc. Replace the copy and branding
> in `lib/editions.ts`, `components/SiteHeader.tsx` and `components/Hero.tsx`
> before putting this in front of anyone.

---

## The three images you need

| Slot | File | Notes |
|---|---|---|
| Backdrop | `public/hero/assets/backdrop.webp` | landscape, no alpha, wide (2800×1563 works well) |
| Figure A | `public/hero/assets/char-a.webp` | cut-out, **real alpha channel**, reaching **left** |
| Figure B | `public/hero/assets/char-b.webp` | cut-out, **real alpha channel**, reaching **left** |

**Both figures reach left.** Figure A is mirrored at runtime so it ends up
reaching right toward Figure B. Generate them the same way; the code flips one.

### What makes a good figure image

- **Full body, mid-stride or airborne.** The timeline throws them past the lens;
  a static standing pose fights that.
- **One arm fully extended, hand at the very edge of the frame.** That hand is
  where the spark fires. A flat figure cannot extend an arm at runtime, so the
  reach has to be in the artwork.
- **Real alpha, not a white background.** A white matte shows as a rectangle.
  Soft edges are fine — `alphaTest: 0.02` keeps hair and fabric.
- **Aspect ratio is free.** The plane sizes itself from the texture; only height
  is fixed (3.6 and 3.7 world units).

### After generating: measure the hands

```bash
npm run measure:hands
```

It prints a `handUV` per image. Paste both into `ASSETS` in
`components/hero/HeroCanvas.tsx`.

This step is not optional. `handUV` is what positions the contact spark. With
guessed values it fires on a figure's chest and the contact beat — the payoff of
the whole scroll — reads as broken. The script finds the outstretched hand by
scanning in from the image edge for the first column with real opacity.

If an arm reaches right instead: `node scripts/measure-hands.mjs --side right`.

### If figure widths change a lot

Contact spacing in `components/hero/timeline.js` is derived from plane width: the
hand sits at the plane's outer edge, so seating a figure at half its own width
puts that hand on the centre line. Current values assume ~2.9 and ~3.8 units
wide. For much wider or narrower artwork, adjust the `p: 0.72` and `p: 0.79` keys
in `CHAR_TRACK`, re-run `npm run preview`, and check
`captures/hero-4-contact.png`.

---

## Structure

```
components/hero/
  HeroCanvas.tsx      React mount + lifecycle; ASSETS and handUV live here
  HeroStage.tsx       420svh scroll region with a sticky viewport-height stage
  HeroScene.js        three.js scene, camera, render loop
  PlaneCharacter.js   a figure as a textured plane
  SparkFX.js          contact spark
  timeline.js         BEATS / CAMERA_TRACK / CHAR_TRACK / easing
```

The page below the hero is 12 content sections driven by `lib/editions.ts` — edit
that file to change copy, section names and feature lists.

### The beats

| Beat | Scroll | What happens |
|---|---|---|
| close | 0.00–0.16 | figures near each other |
| apart | 0.16–0.46 | they drift apart, camera pulls back |
| approach | 0.46–0.72 | they converge, camera pushes in |
| contact | 0.72–0.79 | hands meet, spark fires |
| pass | 0.79–1.00 | they sweep past the lens and dissolve |

Keyed on normalised scroll with no hidden state, so it scrubs correctly in both
directions and survives resize.

---

## Verification

The in-app browser preview cannot verify this page. **A non-displayed pane parks
the tab in `visibilityState: "hidden"`, which suspends `requestAnimationFrame`
outright** — measured, it never fired across 2 s. The scene never starts and
screenshots time out, so a working hero looks broken and a broken one looks fine.

Use headless Chromium instead. It is all wired up:

```bash
npm run preview               # build + restart + capture the six beats
npm run preview -- --probe    # + framing measurements
npm run shoot -- --sections   # one frame per content section
npm run shoot -- --mobile     # 390x844
```

`npm run probe` prints each figure's NDC extents (−1..1 = the viewport), a `fit`
fraction, and where the spark lands — use it rather than guessing whether
something is off screen:

```
p     camera pos/fov       char   ndcX            ndcY            fit
0.46  [0.3,0.75,8.3] 46    charA  [ -0.72, -0.59]  [ -0.65,  0.4]  1
      contact world [0.01,1.84,-1.68] -> ndc [0.01, 0.32]
```

---

## Gotchas

**`next start` keeps serving the `.next` it booted with.** A rebuild alone leaves
stale chunks live and the page 500s on a chunk hash that no longer exists — and
it fails *silently*, because the hero's dynamic import rejects and it falls back
to the painted backdrop. Always restart after building. `scripts/preview.sh` does
it, including the Windows netstat/taskkill path, since `pkill` does not reach the
process there.

**React StrictMode double-mounts and would kill the WebGL context.** The scene is
owned by the canvas element (`canvas.__heroScene`) and published *before* the
`await`; cleanup calls `stop()` and never `dispose()`. Do not "simplify" this —
building a second `WebGLRenderer` on the same canvas yields a dead one that never
finishes loading.

**Content sections are still at opacity 0 after 900 ms** and settle around 2 s.
Screenshot earlier and you photograph the reveal mid-flight and file a contrast
bug that does not exist.

**Points with no `map` render as opaque squares.** `SparkFX` draws its own radial
sprite onto a canvas at construction for exactly this reason.

---

## Fallback behaviour

Progressive by design: if WebGL is unavailable or an image 404s, the catch fires,
the painted backdrop stays visible, and the copy on top stays readable. Keep it.

`prefers-reduced-motion` freezes the idle drift and bob; the scroll scrub still
works.

---

## Not covered

Chromium only. All performance figures come from software rasterisation (62 fps
there, which is a floor rather than a ceiling) — no real-GPU or mobile-device
numbers. No Lighthouse or CLS pass yet.
