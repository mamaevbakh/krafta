import { SECTIONS } from "@/lib/editions";
import { ScrollSpyProvider } from "@/components/ScrollSpy";
import { SiteHeader } from "@/components/SiteHeader";
import { SectionRail } from "@/components/SectionRail";
import { Hero } from "@/components/Hero";
import { EditionSection } from "@/components/EditionSection";
import { SiteFooter } from "@/components/SiteFooter";


/**
 * The whole landing page as one component, so a host app can drop it into a
 * route without reassembling the parts:
 *
 *   import { LandingPage } from "@/components/LandingPage";
 *   export default function Page() { return <LandingPage />; }
 *
 * Styles are not imported here: Tailwind 4 resolves @theme at build time, so
 * landing.css has to be pulled in from the stylesheet that imports Tailwind.
 * See the one-line step in README.
 */
export function LandingPage() {
  return (
    // The wrapper carries the page's own background, text colour and font, so it
    // does not depend on the host styling `body`. Without it, headings that
    // inherit their colour render black on black in an app with default body
    // styles — which is exactly what happened on the first real install.
    <div className="editions-landing">
      <ScrollSpyProvider>
        <SiteHeader />
        <SectionRail />
        <main id="main-content">
          <Hero />
          {SECTIONS.map((section, i) => (
            <EditionSection key={section.id} section={section} index={i} />
          ))}
        </main>
        <SiteFooter />
      </ScrollSpyProvider>
    </div>
  );
}
