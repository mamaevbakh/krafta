"use client";

import { useEffect, useRef, useState } from "react";
import { EDITION, OTHER_EDITIONS } from "@/lib/editions";
import { useScrollSpy } from "./ScrollSpy";

function BagMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden="true">
      <path
        d="M4.6 6.2h10.8l1 11.3H3.6l1-11.3Z"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinejoin="round"
      />
      <path
        d="M7.3 8V5.4a2.7 2.7 0 0 1 5.4 0V8"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function SiteHeader() {
  const { surface, progress } = useScrollSpy();
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const onCream = surface === "cream";
  const fg = onCream ? "text-ink" : "text-cream";

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (!menuRef.current?.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${fg}`}
    >
      <nav className="mx-auto flex h-[3.75rem] max-w-[105rem] items-center gap-4 px-5 sm:px-8">
        <a
          href="#top"
          className="flex shrink-0 items-center gap-2 text-[0.8125rem] font-medium tracking-tight"
        >
          <BagMark className="size-[1.15rem]" />
          <span className="hidden sm:inline">{EDITION.name}</span>
        </a>

        <div className="relative ml-auto" ref={menuRef}>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-haspopup="menu"
            className={`flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-[0.8125rem] transition-colors duration-300 ${
              onCream
                ? "border-ink/25 hover:bg-ink/5"
                : "border-cream/25 hover:bg-cream/10"
            }`}
          >
            {EDITION.season}
            <svg
              viewBox="0 0 10 6"
              className={`size-2.5 transition-transform duration-200 ${
                open ? "rotate-180" : ""
              }`}
              aria-hidden="true"
            >
              <path
                d="M1 1l4 4 4-4"
                stroke="currentColor"
                strokeWidth="1.4"
                fill="none"
                strokeLinecap="round"
              />
            </svg>
          </button>

          {open && (
            <div
              role="menu"
              className="absolute right-0 top-[calc(100%+0.5rem)] w-60 overflow-hidden rounded-xl border border-cream/15 bg-canvas/95 p-1.5 text-cream shadow-2xl backdrop-blur-md"
            >
              {OTHER_EDITIONS.map((ed) => (
                <a
                  key={ed.label}
                  href={ed.href}
                  role="menuitem"
                  className={`flex items-baseline justify-between gap-3 rounded-lg px-3 py-2 text-sm transition-colors hover:bg-cream/10 ${
                    ed.current ? "bg-cream/10" : ""
                  }`}
                >
                  <span>{ed.label}</span>
                  <span className="font-serif text-xs text-stone-2 italic">
                    {ed.codename}
                  </span>
                </a>
              ))}
              <div className="mt-1.5 border-t border-cream/10 px-3 py-2">
                <a href="#" className="text-sm text-stone-2 link-underline">
                  View all Editions
                </a>
              </div>
            </div>
          )}
        </div>

        <a
          href="#"
          className={`hidden rounded-full px-4 py-1.5 text-[0.8125rem] font-medium transition-colors duration-300 sm:block ${
            onCream
              ? "bg-ink text-cream hover:bg-ink/85"
              : "bg-cream text-ink hover:bg-stone-1"
          }`}
        >
          Start free trial
        </a>
      </nav>

      <div
        className={`h-px origin-left transition-colors duration-300 ${
          onCream ? "bg-ink/40" : "bg-cream/40"
        }`}
        style={{ transform: `scaleX(${progress})` }}
        aria-hidden="true"
      />
    </header>
  );
}
