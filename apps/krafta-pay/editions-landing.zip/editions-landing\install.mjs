/**
 * Installs the landing page into a Next.js app.
 *
 *   node install.mjs ../my-app
 *   node install.mjs ../my-app --force     # overwrite existing files
 *   node install.mjs ../my-app --dry-run
 *
 * Copies code and assets, then prints the few things it cannot do for you —
 * installing dependencies, one stylesheet import, and the font variables. It
 * refuses to clobber files that already exist unless --force, so running it
 * against an app that already has a components/Hero.tsx tells you rather than
 * quietly replacing it.
 */
import { cpSync, existsSync, mkdirSync, readFileSync, statSync, readdirSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const argv = process.argv.slice(2);
const target = argv.find((a) => !a.startsWith("--"));
const force = argv.includes("--force");
const dry = argv.includes("--dry-run");

if (!target) {
  console.error("usage: install-into.mjs <target-app-dir> [--force] [--dry-run]");
  process.exit(1);
}

// The bundle is the source: every path below is relative to this file.
const SRC = path.dirname(fileURLToPath(import.meta.url));
const DST = path.resolve(target);

if (!existsSync(DST)) {
  console.error(`target does not exist: ${DST}`);
  process.exit(1);
}

/** Everything that has to travel, as source -> destination pairs. */
const ITEMS = [
  ["components/hero", "components/hero"],
  ["components/landing.css", "components/landing.css"],
  ["components/LandingPage.tsx", "components/LandingPage.tsx"],
  ["components/EditionSection.tsx", "components/EditionSection.tsx"],
  ["components/FeatureMedia.tsx", "components/FeatureMedia.tsx"],
  ["components/Hero.tsx", "components/Hero.tsx"],
  ["components/Reveal.tsx", "components/Reveal.tsx"],
  ["components/ScrollSpy.tsx", "components/ScrollSpy.tsx"],
  ["components/SectionRail.tsx", "components/SectionRail.tsx"],
  ["components/SiteFooter.tsx", "components/SiteFooter.tsx"],
  ["components/SiteHeader.tsx", "components/SiteHeader.tsx"],
  ["lib/editions.ts", "lib/editions.ts"],
  ["public/hero/assets", "public/hero/assets"],
  // The capture harness travels too: without it there is no way to verify the
  // hero, because a hidden browser tab suspends rAF and the scene never starts.
  ["measure-hands.mjs", "scripts/measure-hands.mjs"],
  ["shoot.mjs", "scripts/shoot.mjs"],
  ["frame-probe.mjs", "scripts/frame-probe.mjs"],
  ["preview.sh", "scripts/preview.sh"],
];

const copied = [];
const skipped = [];

for (const [from, to] of ITEMS) {
  const src = path.join(SRC, from);
  const dst = path.join(DST, to);
  if (!existsSync(src)) { console.warn(`  missing in source, skipping: ${from}`); continue; }

  if (existsSync(dst) && !force) {
    skipped.push(to);
    continue;
  }
  if (!dry) {
    mkdirSync(path.dirname(dst), { recursive: true });
    cpSync(src, dst, { recursive: true });
  }
  copied.push(to);
}

const count = (p) => {
  const f = path.join(SRC, p);
  if (!existsSync(f)) return 0;
  return statSync(f).isDirectory() ? readdirSync(f).length : 1;
};

console.log(`${dry ? "[dry run] would copy" : "copied"} ${copied.length} item(s) into ${DST}`);
for (const c of copied) console.log(`  + ${c}${count(c) > 1 ? ` (${count(c)} files)` : ""}`);
if (skipped.length) {
  console.log(`\nskipped ${skipped.length} existing file(s) — re-run with --force to overwrite:`);
  for (const s of skipped) console.log(`  ! ${s}`);
}

/* ---------- what the script cannot do ---------- */

const need = { three: "^0.185.1" };
let missing = need;
const pkgPath = path.join(DST, "package.json");
if (existsSync(pkgPath)) {
  const pkg = JSON.parse(readFileSync(pkgPath, "utf8"));
  const have = { ...pkg.dependencies, ...pkg.devDependencies };
  missing = Object.fromEntries(Object.entries(need).filter(([n]) => !have[n]));
}

console.log("\n--- remaining steps ---\n");

let step = 1;
if (Object.keys(missing).length) {
  console.log(`${step++}. Install:\n     npm i ${Object.entries(missing).map(([n, v]) => `${n}@${v}`).join(" ")}`);
  console.log(`   Optional, for the capture harness:  npm i -D playwright sharp && npx playwright install chromium\n`);
} else {
  console.log(`${step++}. Dependencies already present.\n`);
}

console.log(`${step++}. Add ONE line to the stylesheet that imports Tailwind (usually app/globals.css),`);
console.log(`   directly after the Tailwind import:\n`);
console.log(`     @import "tailwindcss";`);
console.log(`     @import "../components/landing.css";   <- add this\n`);
console.log(`   Tailwind 4 resolves @theme at build time, so a JS import will not work.`);
console.log(`   Without this the page renders unstyled.\n`);

console.log(`${step++}. Fonts — the page expects two CSS variables. In app/layout.tsx:\n`);
console.log(`     import { Inter_Tight, EB_Garamond } from "next/font/google";`);
console.log(`     const grotesk  = Inter_Tight({ variable: "--font-grotesk", subsets: ["latin"], weight: ["400","500","700"] });`);
console.log(`     const garamond = EB_Garamond({ variable: "--font-garamond", subsets: ["latin"], weight: ["400","500"], style: ["normal","italic"] });`);
console.log(`     <html className={\`\${grotesk.variable} \${garamond.variable}\`}>\n`);
console.log(`   Any grotesk + serif pair works; only the variable names matter.\n`);

console.log(`${step++}. Render it:\n`);
console.log(`     import { LandingPage } from "@/components/LandingPage";`);
console.log(`     export default function Page() { return <LandingPage />; }\n`);
console.log(`   Needs the "@/*" path alias in tsconfig.json. If the host uses a different`);
console.log(`   alias, adjust the imports at the top of LandingPage.tsx.\n`);

console.log(`${step++}. Replace the copy and branding in lib/editions.ts, components/SiteHeader.tsx`);
console.log(`   and components/Hero.tsx — it is currently Shopify's marketing text.\n`);

console.log(`Then verify:  bash scripts/preview.sh`);
console.log(`(The in-app browser preview cannot check this — a hidden tab suspends rAF`);
console.log(` and the WebGL hero never starts.)`);
